# iFunnyAPI
###### Interact with iFunny's API using python!